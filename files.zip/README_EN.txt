═══════════════════════════════════════════════════════════════
  OHHamLogger v1.2.0
  Amateur Radio Logging Software
═══════════════════════════════════════════════════════════════

DESCRIPTION:
-----------
OHHamLogger is a simple and efficient logging program for amateur
radio operators. Developed especially for WWFF activations, but
suitable for all general QSO logging.

FEATURES:
---------
• ADI 3.1.0 file format support
• Automatic WWFF reference recognition
• FreeDV, FT8, FT4, CW, SSB and other digital modes
• GMT/UTC timestamps with 24h system
• Edit and delete QSOs during runtime
• Merge logs in chronological order
• Duplicate detection
• 5 color themes (including retro theme)
• Finnish and English user interface

SYSTEM REQUIREMENTS:
-------------------
• Python 3.8 or newer
• Tkinter (included in most Python installations)
• Operating System: Windows, Linux, macOS

INSTALLATION:
------------
1. Install Python 3.8+ (if not already installed)
2. Download OHHamLog1_2_0_TOIMIVA_VERSIO.py
3. Run command: python OHHamLog1_2_0_TOIMIVA_VERSIO.py

Linux/macOS:
  python3 OHHamLog1_2_0_TOIMIVA_VERSIO.py

Windows:
  python OHHamLog1_2_0_TOIMIVA_VERSIO.py
  or double-click the file

QUICK START:
-----------
1. Start the program
2. Set in settings:
   - Your callsign
   - Default bands and modes
   - WWFF reference (if activating)
   - QTH locator
3. Input line: OH1ABC 59 59
   or with WWFF: OH1ABC 59 59 OHFF-1234
4. Press Enter to save
5. Save log: File → Save log

INPUT FORMATS:
-------------
Basic QSO:
  OH1ABC 59 59

WWFF activation:
  OH1ABC 59 59 OHFF-1234

With comment:
  OH1ABC 59 59 OHFF-1234 Nice QSO

Callsign only (uses default reports):
  OH1ABC

BANDS:
------
160m, 80m, 60m, 40m, 30m, 20m, 17m, 15m, 12m, 10m, 6m, 2m, 70cm

MODES:
------
SSB, LSB, USB, CW, FM, AM, FT8, FT4, RTTY, PSK, FreeDV

WWFF RECOGNITION:
----------------
Supported formats:
• OHFF-1234 (Finland)
• DLFF-1234 (Germany)
• GFF-1234 (United Kingdom)
• GMFF-1234, GWFF-1234, etc. (UK regions)
• FF-OH-1234 (alternative format)

WWFF reference is automatically recognized and saved to
SIG and SIG_INFO fields according to ADI standard.

THEMES:
-------
1. Default - Dark blue-gray, modern look
2. Night - Dark gray, eye-friendly
3. Retro - Black background, green text (CRT terminal)
4. Elegant - Blue, stylish colors
5. Classic Amateur - Windows 95 gray, nostalgic

RUNTIME EDITING:
---------------
• Double-click log row → Edit QSO
• Right mouse button → Edit/Delete menu
• Editable fields:
  - Callsign
  - Band
  - Mode
  - RST sent/received
  - WWFF reference
  - Comment

LOG MERGING:
-----------
File → Merge logs
• Select two ADI logs
• Merges in chronological order
• Automatically removes duplicates

FILE FORMAT:
-----------
• ADI 3.1.0 standard
• UTF-8 character encoding
• Filename: OH3ENK@OHFF-0029.adi
  or: OH3ENK@KP20TH.adi
  or: OH3ENK.adi

COMPATIBILITY:
-------------
Also reads old/incorrect ADI files ("shitlogs"):
• DATE field (old format)
• WWFF_REF and MY_WWFF_REF (old fields)
• Fields on one line (non-standard format)

KEYBOARD SHORTCUTS:
------------------
Enter           - Save QSO
Double-click    - Edit QSO
Right mouse     - Edit/Delete menu

TROUBLESHOOTING:
---------------
Problem: WWFF reference appears in comment field
Solution: Old log. Edit QSO and remove WWFF from comment.

Problem: Cannot open old log
Solution: v1.2.0 supports old formats (DATE, WWFF_REF).

Problem: Time is wrong
Solution: All times are GMT/UTC. Check system time zone.

Problem: Cannot edit band/mode
Solution: Feature added in v1.2.0. Update to latest version.

FUTURE FEATURES:
---------------
• DXCC recognition
• CQ/ITU zones
• Contest logging
• LOTW integration
• Map display
• Statistics and awards
• Cabrillo export
• DX cluster integration

CREDITS:
--------
Developer: OH3ENK
Version: 1.2.0
Updated: December 1, 2024
License: Open Source

Thanks to:
• Finnish amateur radio community
• WWFF program
• ADI standard maintainers
• Beta testers

SUPPORT AND FEEDBACK:
--------------------
SourceForge: https://sourceforge.net/projects/ohhamlogger/
Bugs: Use SourceForge issue tracker
Feedback: Leave a review or comment on SourceForge

LICENSE:
--------
This program is free software. You may modify and distribute it
freely. See LICENSE file for details.

DISCLAIMER:
----------
This program is provided "as is" without any warranties.
The developer is not responsible for any damages or data loss.

CHANGELOG:
---------
v1.2.0 (December 1, 2024):
• FreeDV mode added
• Improved WWFF recognition
• GMT/UTC time and 24h system
• Runtime editing and deletion
• Merge logs in chronological order
• 5 color themes
• Fixed QSO log colors
• Compatibility with old logs

v1.1.1 (previous):
• Basic logging
• ADI save
• WWFF support
• Settings

═══════════════════════════════════════════════════════════════
WHAT IS A "SHITLOG"?
═══════════════════════════════════════════════════════════════

A "shitlog" is amateur radio slang for a poorly formatted ADI
log file that doesn't follow proper ADI 3.1.0 standards. These
logs are often created by older or non-compliant logging software.

Common issues in shitlogs:
❌ All fields on one line instead of separate lines
❌ Uses DATE instead of QSO_DATE
❌ Uses WWFF_REF instead of SIG_INFO
❌ Missing proper field spacing
❌ Incorrect field ordering

OHHamLogger v1.2.0 can read these shitlogs by supporting:
✓ Both DATE and QSO_DATE
✓ Both WWFF_REF and SIG_INFO
✓ Flexible field parsing
✓ Fields on single or multiple lines

This ensures your old logs remain accessible even if they were
created with less strict logging software.

═══════════════════════════════════════════════════════════════
EXAMPLE USAGE:
═══════════════════════════════════════════════════════════════

Portable operation from WWFF site:
1. Set your call: OH3ENK
2. Set WWFF ref: OHFF-0029
3. Set locator: KP20TH
4. Select band: 40m
5. Select mode: SSB

Log QSOs:
  OH1ABC 59 59
  OH2DEF 59 57 OHFF-1234
  OH3GHI 59 59 OHFF-1234 Nice signal!

Save as: OH3ENK@OHFF-0029.adi

The log automatically includes:
• Your WWFF reference in MY_SIG_INFO
• Other station's WWFF in SIG_INFO
• GMT/UTC timestamps
• Proper ADI 3.1.0 format

═══════════════════════════════════════════════════════════════
73 de OH3ENK!

Amateur radio connects the world!
═══════════════════════════════════════════════════════════════
