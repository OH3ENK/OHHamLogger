═══════════════════════════════════════════════════════════════
  OHHamLogger v1.2.0
  Radioamatöörilokiohjelma
═══════════════════════════════════════════════════════════════

KUVAUS:
-------
OHHamLogger on yksinkertainen ja tehokas lokiohjelma radioamatööreille.
Ohjelma on kehitetty erityisesti WWFF-aktivaatioiden lokitukseen, mutta
soveltuu kaikkeen yleiseen QSO-kirjanpitoon.

OMINAISUUDET:
-------------
• ADI 3.1.0 -tiedostomuodon tuki
• WWFF-viitteiden automaattinen tunnistus
• FreeDV, FT8, FT4, CW, SSB ja muut digitaalimodet
• GMT/UTC aikaleimaus 24h järjestelmällä
• QSO:iden muokkaus ja poisto ajon aikana
• Lokien yhdistäminen aikajärjestykseen
• Duplikaattien tunnistus
• 5 eri väriteemaa (sis. retro-teema)
• Suomen- ja englanninkielinen käyttöliittymä

JÄRJESTELMÄVAATIMUKSET:
----------------------
• Python 3.8 tai uudempi
• Tkinter (sisältyy useimpiin Python-asennuksiin)
• Käyttöjärjestelmä: Windows, Linux, macOS

ASENNUS:
--------
1. Asenna Python 3.8+ (jos ei ole jo asennettu)
2. Lataa OHHamLog1_2_0_TOIMIVA_VERSIO.py
3. Suorita komento: python OHHamLog1_2_0_TOIMIVA_VERSIO.py

Linux/macOS:
  python3 OHHamLog1_2_0_TOIMIVA_VERSIO.py

Windows:
  python OHHamLog1_2_0_TOIMIVA_VERSIO.py
  tai kaksoisklikkaa tiedostoa

PIKA-ALOITUS:
------------
1. Käynnistä ohjelma
2. Aseta asetuksista:
   - Oma kutsumerkki
   - Oletusbandit ja modet
   - WWFF-viite (jos aktivaatiossa)
   - QTH-lokaattori
3. Syöttörivi: OH1ABC 59 59
   tai WWFF:llä: OH1ABC 59 59 OHFF-1234
4. Paina Enter tallentaaksesi
5. Tallenna loki: Tiedosto → Tallenna loki

SYÖTTÖMUODOT:
------------
Perus QSO:
  OH1ABC 59 59

WWFF-aktivaatiossa:
  OH1ABC 59 59 OHFF-1234

Kommentilla:
  OH1ABC 59 59 OHFF-1234 Mukava QSO

Vain kutsumerkki (käyttää oletusraportteja):
  OH1ABC

BANDIT:
-------
160m, 80m, 60m, 40m, 30m, 20m, 17m, 15m, 12m, 10m, 6m, 2m, 70cm

MODET:
------
SSB, LSB, USB, CW, FM, AM, FT8, FT4, RTTY, PSK, FreeDV

WWFF-TUNNISTUS:
--------------
Tuetut muodot:
• OHFF-1234 (Suomi)
• DLFF-1234 (Saksa)
• GFF-1234 (Iso-Britannia)
• GMFF-1234, GWFF-1234, etc. (UK-alueet)
• FF-OH-1234 (vaihtoehtoinen)

WWFF-viite tunnistetaan automaattisesti ja tallennetaan
SIG ja SIG_INFO -kenttiin ADI-standardin mukaisesti.

TEEMAT:
-------
1. Oletus - Tumma siniharmaa, moderni ulkoasu
2. Yö - Tumma harmaa, silmiä säästävä
3. Retro - Musta tausta, vihreä teksti (CRT-terminaali)
4. Elegantti - Sininen, tyylikkäät värit
5. Klassinen amatööri - Windows 95 -harmaa, nostalginen

MUOKKAUS AJON AIKANA:
--------------------
• Kaksoisklikkaa lokirivistä → Muokkaa QSO:ta
• Oikea hiiren painike → Muokkaa/Poista valikko
• Muokattavat kentät:
  - Kutsumerkki
  - Bandi
  - Mode
  - RST lähetetty/vastaanotettu
  - WWFF-viite
  - Kommentti

LOKIEN YHDISTÄMINEN:
-------------------
Tiedosto → Yhdistä lokit
• Valitse kaksi ADI-lokia
• Yhdistää aikajärjestykseen
• Poistaa duplikaatit automaattisesti

TIEDOSTOMUOTO:
-------------
• ADI 3.1.0 -standardi
• UTF-8 merkistökoodaus
• Tiedostonimi: OH3ENK@OHFF-0029.adi
  tai: OH3ENK@KP20TH.adi
  tai: OH3ENK.adi

YHTEENSOPIVUUS:
--------------
Lukee myös vanhoja/virheellisiä ADI-tiedostoja:
• DATE-kenttä (vanha muoto)
• WWFF_REF ja MY_WWFF_REF (vanhat kentät)
• Kentät yhdellä rivillä (ei-standardimuoto)

PIKANÄPPÄIMET:
-------------
Enter           - Tallenna QSO
Kaksoisklikkaus - Muokkaa QSO:ta
Oikea hiiri     - Muokkaa/Poista valikko

VIANMÄÄRITYS:
------------
Ongelma: WWFF-viite näkyy kommentti-kentässä
Ratkaisu: Vanha loki. Muokkaa QSO ja poista WWFF kommentista.

Ongelma: En voi avata vanhaa lokia
Ratkaisu: v1.2.0 tukee vanhojakin formaatteja (DATE, WWFF_REF).

Ongelma: Aika on väärin
Ratkaisu: Kaikki ajat GMT/UTC. Tarkista järjestelmän aikavyöhyke.

Ongelma: En voi muokata bandia/modea
Ratkaisu: Ominaisuus lisätty v1.2.0:ssa. Päivitä uusimpaan versioon.

TULEVAT OMINAISUUDET:
--------------------
• DXCC-tunnistus
• CQ/ITU-vyöhykkeet
• Kilpailulokitus
• LOTW-integraatio
• Karttanäkymä
• Tilastot ja diplomit
• Cabrillo-vienti
• DX-cluster-integraatio

TEKIJÄTIEDOT:
------------
Kehittäjä: OH3ENK
Versio: 1.2.0
Päivitetty: 1.12.2024
Lisenssi: Avoin lähdekoodi

Kiitokset:
• Suomen radioamatööriyhteisö
• WWFF-ohjelma
• ADI-standardin ylläpitäjät
• Beeta-testaajat

TUKI JA PALAUTE:
---------------
SourceForge: https://sourceforge.net/projects/ohhamlogger/
Bugit: Käytä SourceForgen issue trackeria
Palaute: Jätä arvostelu tai kommentti SourceForgeen

LISENSSI:
---------
Tämä ohjelma on vapaa ohjelmisto. Saat muokata ja jakaa sitä
vapaasti. Katso LICENSE-tiedosto lisätietoja varten.

VASTUUVAPAUSLAUSEKE:
-------------------
Tämä ohjelma toimitetaan "sellaisenaan" ilman minkäänlaisia
takuita. Kehittäjä ei ole vastuussa mahdollisista vahingoista
tai tietojen menetyksestä.

MUUTOSLOKI:
----------
v1.2.0 (1.12.2024):
• FreeDV-mode lisätty
• WWFF-tunnistus parannettu
• GMT/UTC aika ja 24h järjestelmä
• Muokkaus ja poisto ajon aikana
• Lokien yhdistäminen aikajärjestykseen
• 5 väriteemaa
• QSO-lokin värit korjattu
• Yhteensopivuus vanhojen lokien kanssa

v1.1.1 (aiempi):
• Peruslokinpito
• ADI-tallennus
• WWFF-tuki
• Asetukset

═══════════════════════════════════════════════════════════════
73 de OH3ENK!

Radioamatööritoiminta yhdistää maailmaa!
═══════════════════════════════════════════════════════════════
